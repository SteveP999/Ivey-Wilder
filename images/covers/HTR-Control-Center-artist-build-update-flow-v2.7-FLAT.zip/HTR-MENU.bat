@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Hello Texas Records Control Center
cd /d D:\HTR-Control-Center

:MENU
cls
echo ==================================================
echo        HELLO TEXAS RECORDS CONTROL CENTER v2.7
echo ==================================================
echo.
echo DAILY OPERATIONS
echo   1. Add New Artist
echo   2. Add Album From Folder
echo   3. Add New Song to Existing Artist
echo   4. Build / Preview One Artist Site
echo.
echo LABEL SITE DATA
echo   5. Rebuild + Preview HelloTexasRecords.com
echo   6. Rebuild HTR Radio Data
echo   7. Full Label Data Rebuild
echo.
echo PUBLISH
echo   8. Publish HelloTexasRecords.com Repo
echo   9. Publish Specific Artist Repo
echo.
echo AUDIT / REPAIR
echo  10. Validate Master Songs
echo  11. Find Missing Audio Links
echo.
echo   0. Exit
echo.
echo ==================================================
set /p choice=What do you want to do? 

if "%choice%"=="1" goto ADD_ARTIST
if "%choice%"=="2" goto ADD_ALBUM
if "%choice%"=="3" goto ADD_SONG
if "%choice%"=="4" goto BUILD_ARTIST_SITE
if "%choice%"=="5" goto PREVIEW_HOMEPAGE
if "%choice%"=="6" goto BUILD_RADIO
if "%choice%"=="7" goto FULL_REBUILD
if "%choice%"=="8" goto PUBLISH_LABEL
if "%choice%"=="9" goto PUBLISH_ARTIST
if "%choice%"=="10" goto VALIDATE_MASTER
if "%choice%"=="11" goto FIND_MISSING_AUDIO
if "%choice%"=="0" goto END

echo.
echo Invalid option.
pause
goto MENU

:RUNSCRIPT
set script_title=%~1
set bat_file=%~2
set py_file=%~3

cls
echo ==================================================
echo %script_title%
echo ==================================================
echo.

if exist "%bat_file%" (
  call "%bat_file%"
  goto AFTER_RUN
)

if not "%py_file%"=="" if exist "%py_file%" (
  python "%py_file%"
  goto AFTER_RUN
)

echo Missing script:
echo %bat_file%
if not "%py_file%"=="" echo %py_file%

:AFTER_RUN
echo.
echo ==================================================
echo Done: %script_title%
echo ==================================================
pause
goto MENU

:ADD_ARTIST
call :RUNSCRIPT "ADD ARTIST" "create-artist.bat" "scripts\create-artist.py"

:ADD_ALBUM
call :RUNSCRIPT "ADD ALBUM FROM FOLDER" "add-album-from-folder.bat" "scripts\add-album-from-folder.py"

:ADD_SONG
call :RUNSCRIPT "ADD NEW SONG TO EXISTING ARTIST" "add-song.bat" "scripts\add-song.py"

:BUILD_ARTIST_SITE
call :RUNSCRIPT "BUILD / PREVIEW ARTIST SITE" "build-preview-update-artist.bat" ""

:PREVIEW_HOMEPAGE
call :RUNSCRIPT "REBUILD + LOCAL SERVER PREVIEW HOMEPAGE" "preview-homepage.bat" "scripts\preview-homepage.py"

:BUILD_RADIO
call :RUNSCRIPT "REBUILD RADIO DATA" "build-radio-data.bat" "scripts\build-radio-data.py"

:FULL_REBUILD
cls
echo ==================================================
echo FULL LABEL DATA REBUILD
echo ==================================================
echo.
echo This will run:
echo 1. rebuild + preview homepage
echo 2. build-radio-data
echo.
set /p confirm=Continue? Y/N: 
if /I not "%confirm%"=="Y" goto MENU

call "preview-homepage.bat"
if exist "build-radio-data.bat" (
  call "build-radio-data.bat"
) else if exist "scripts\build-radio-data.py" (
  python "scripts\build-radio-data.py"
) else (
  echo Missing radio build script.
)
pause
goto MENU

:PUBLISH_LABEL
cls
echo ==================================================
echo PUBLISH HELLO TEXAS RECORDS REPO
echo ==================================================
echo.
if exist "D:\hello-texas-records\update.bat" (
  cd /d D:\hello-texas-records
  call update.bat
  cd /d D:\HTR-Control-Center
) else (
  echo Missing D:\hello-texas-records\update.bat
)
pause
goto MENU

:PUBLISH_ARTIST
cls
echo ==================================================
echo PUBLISH SPECIFIC ARTIST REPO
echo ==================================================
echo.
set /p artist_folder=Artist repo folder name on D: drive ^(example: Ivey-Wilder^): 

if "%artist_folder%"=="" goto MENU

if exist "D:\%artist_folder%\update.bat" (
  cd /d "D:\%artist_folder%"
  call update.bat
  cd /d D:\HTR-Control-Center
) else (
  echo Missing update.bat in:
  echo D:\%artist_folder%
)
pause
goto MENU

:VALIDATE_MASTER
call :RUNSCRIPT "VALIDATE MASTER SONGS" "validate-master-songs.bat" "scripts\validate-master-songs.py"

:FIND_MISSING_AUDIO
call :RUNSCRIPT "FIND MISSING AUDIO LINKS" "find-missing-audio.bat" "scripts\find-missing-audio.py"

:END
cls
echo Goodbye.
endlocal
exit /b 0
