@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Build / Preview / Optional Update Artist
cd /d D:\HTR-Control-Center

echo ==================================================
echo BUILD / PREVIEW ONE ARTIST SITE v2.7
echo ==================================================
echo.

REM Run the existing artist builder exactly as before.
if exist "build-artist-site.bat" (
    call "build-artist-site.bat"
) else if exist "scripts\build-artist-site.py" (
    python "scripts\build-artist-site.py"
) else (
    echo ERROR: Missing build-artist-site.bat or scripts\build-artist-site.py
    pause
    exit /b 1
)

echo.
echo ==================================================
echo BUILD COMPLETE
echo ==================================================
echo.
echo Run the artist repo update now?
echo.
set /p do_update=Run update? (Y/n): 

if /I "%do_update%"=="n" goto DONE
if /I "%do_update%"=="no" goto DONE

echo.
set /p artist_folder=Artist repo folder on D: drive ^(example: Ivey-Wilder^): 

if "%artist_folder%"=="" (
    echo No artist folder entered. Skipping update.
    goto DONE
)

if exist "D:\%artist_folder%\update.bat" (
    echo.
    echo Running:
    echo D:\%artist_folder%\update.bat
    echo.
    cd /d "D:\%artist_folder%"
    call update.bat
    cd /d D:\HTR-Control-Center
) else (
    echo.
    echo ERROR: update.bat not found:
    echo D:\%artist_folder%\update.bat
)

:DONE
echo.
echo Done.
pause
endlocal
exit /b 0
